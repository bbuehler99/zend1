<?php
return [
    'view_helpers' => [
        'invokables' => [
            'losrecaptcha/recaptcha' => 'LosReCaptcha\Form\View\Helper\Captcha\ReCaptcha',
        ],
    ],
];
